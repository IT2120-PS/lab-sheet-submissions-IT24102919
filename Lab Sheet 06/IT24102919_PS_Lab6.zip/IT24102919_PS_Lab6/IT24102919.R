setwd("C:\\Users\\acer\\Desktop\\IT24102919_PS_Lab6")

#Question1
#part 1
#Random variable X has binomial distribution with n = 50 and p = 0.85

#part 2
dbinom(46, 50, 0.85)
pbinom(46, 50, 0.85, lower.tail = FALSE)

#Question 2
#part 1
#X = number of calls receive by the call center per hour

#part 2
#Poisson Distribution
#Random variable X has poisson distribution with lamda = 12

#part 3
#P(X = 15)
dpois(15,12)

